# Compression and coverage rules

## Separate extraction from prioritization

Create a complete internal claim inventory before ranking importance. For each
claim record: ID, type (fact asserted/opinion/proposal/request/question),
explicitness (explicit/inferred), concise faithful wording, consequence,
priority, and evidence location. Avoid clustering incompatible claims.

## Preserve decision-critical meaning

Keep these even if they are isolated or mentioned only once:
- Safety, security, privacy, legal, financial, compliance, or production risk.
- Blockers, dependencies, hard deadlines, and irreversible actions.
- Negations, caveats, conditions, exceptions, uncertainties and disagreements.
- A directly addressed request or a decision needed from the reader.
- Evidence contradicting the headline conclusion.

## Compression quality gate

1. Are all extracted P0/P1 claims represented in the first view?
2. Does the compressed wording preserve qualifiers and negation?
3. Can the reader distinguish the author's view from verified facts?
4. Are inferred actions labeled as inferred?
5. Are claim IDs uniquely assigned and linked to exact source locations?
6. Does an additional-issues count warn about hidden P2/P3 claims?
7. Does the result state incomplete input / inaccessible sources?

If any check fails, warn the reader and include enough detail to resolve the
failure. Don't offer a misleadingly confident compressed decision.

## Recommended interaction

- `expand Cxx`: reveal details, limits and exact source pointers.
- `source Cxx`: show a short exact excerpt and/or opening location.
- `all claims`: show the full claim inventory.
- `risks only`: show every P0 and consequential P1, not merely top three.
