# Output formats

## Human-readable

Default to the `SKILL.md` Japanese format. Use small, structured sections:
one-sentence main point, reader action, a few top issues, crucial exceptions,
source pointers. Reference IDs are mandatory for important issues when their
sources can be anchored.

## Optional machine-readable record

For workflows that save files, write a sidecar mapping such as:

```yaml
source:
  id: message-001
  original_path: originals/message-001.md
  sha256: "<actual sha256 if computed>"
  retained: true
claims:
  - id: C01
    priority: P1
    type: request
    explicit: true
    statement: "API timeout policy needs a decision"
    evidence:
      source_id: message-001
      paragraph_ids: [P03]
      exact_quote: "<an exact, short excerpt from P03>"
    status: unverified
coverage:
  input_complete: true
  p0_p1_covered: true
  notes: []
```

Never fabricate a hash, location, quote, or a `retained: true` flag.
For long-lived references, preserve source snapshots or immutable version IDs.
If source cannot be retained, clearly mark the compressed representation as
**not reversibly traceable** and include precise citations where possible.
