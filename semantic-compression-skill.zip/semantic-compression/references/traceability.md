# Traceability specification

## Source anchoring hierarchy

1. Immutable original snapshot + stable paragraph/line spans + content hash.
2. Versioned document URI + page/section/line span.
3. Message ID + quoted excerpt and timestamp (if actually known).
4. Temporary paragraph IDs and exact quotes for pasted text.

Do not assert that a generic URL will remain immutable or accessible.

## Minimal storage discipline

Keep an untouched copy of the original under `originals/` if the runtime and
user permissions permit. Place claim mappings in a separate YAML/JSON file.
Preserve encoding and line endings if exact byte reconstruction matters.
For confidential data, avoid copying unless explicitly authorized; an existing
secure message identifier may be preferable to creating another copy.

## Reversibility levels

- **R2 — Snapshot-backed:** original bytes saved and identified by hash; exact
  bytes can be retrieved from snapshot storage.
- **R1 — Reference-backed:** stable source location expected accessible; exact
  retrieval is conditional on source availability/version.
- **R0 — Compression-only:** no retrievable source, so original cannot be
  reconstructed; disclose this limitation.

Always describe which level applies. None of these means the LLM can regenerate
original text solely from compressed claims.
