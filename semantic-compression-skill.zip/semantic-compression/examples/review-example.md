# Example: technical review

## Original (illustrative)

[P01] 外部APIとの通信について、タイムアウト値が設計上明示されていません。
応答が遅延した際に処理が滞留する可能性があります。

[P02] また、一時的な通信エラーに対するリトライ回数・間隔も未整理です。
ただし、非冪等な更新APIでは安易な再試行は避ける必要があります。

[P03] 障害解析を容易にするため、構造化ログやメトリクスの追加も検討できます。

## Compressed view

### 一言でいうと
外部API障害時の挙動について、先に決めるべき事項が2点あります。

### 私に必要な対応
**判断**：タイムアウト方針と、更新APIを含むリトライ方針を決める。

### 重要な論点
- `[C01/P1]` タイムアウト値が未定義で処理滞留の懸念 → P01
- `[C02/P1]` リトライ方針が未定義。非冪等APIは再試行条件に注意 → P02
- `[C03/P2]` 構造化ログ・メトリクスの追加提案 → P03

### 参照と詳細
この例のP01–P03は上の原文段落です。原文を保持している場合のみ
R2（スナップショットあり）と表現できます。このMarkdownだけを会話中で
参照できる状況は、永続化保証がないためR0または一時参照です。

## Why this matters

The exception concerning non-idempotent update APIs is preserved, even though
it makes the compressed output a little longer. Leaving it out would change a
reader's decision.
