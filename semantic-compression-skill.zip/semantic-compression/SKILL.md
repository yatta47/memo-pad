---
name: semantic-compression
description: >
  Compress verbose incoming messages, reviews, feedback, and documents into
  decision-oriented layers while preserving explicit source traceability.
  Use for long AI-generated text or whenever the reader needs to minimize
  cognitive load without overlooking important points.
---

# Semantic Compression

## Objective

Reduce **reading effort**, not the integrity of information. Present what the
reader needs to understand or decide first, then offer traceable drill-down to
source evidence. This is not conventional summarization.

**Reversibility definition:** LLM text compression is not inherently lossless.
"Reversible" here means that the original input is retained (or its durable
reference is known to be accessible) and each extracted claim points to the
original passage. Never claim exact recovery from compressed text alone.

## Workflow

1. **Register source**: record a source ID, URI/path or message identifier,
   content version/hash if known, and whether the full original is accessible.
   If there is no reliable source pointer, include a short exact evidence quote.
2. **Inventory before compressing**: extract distinct claims, requests,
   proposed actions, decisions, factual assertions, supporting evidence,
   constraints, caveats, contradictions, and unresolved questions.
   Differentiate what is *explicit* from what is *inferred*.
3. **Prioritize by consequences**:
   - P0: blocker, high-impact risk, irreversible or safety-critical issue.
   - P1: requested decision or action, critical dependency.
   - P2: supporting rationale or meaningful suggestion.
   - P3: context, repetition, optional detail.
   Priority is a provisional reading aid; do not assert it is objective.
4. **Build progressive views**:
   - **L1 — Glance**: one-sentence gist, what I need to do (or none/unclear),
     and any critical warning.
   - **L2 — Decisions**: up to three leading issues by default, with priority,
     implication, and source anchors. If more issues exist, state the count and
     where to find them. Never hide additional P0/P1 issues for the sake of three.
   - **L3 — Evidence**: full claim inventory with source anchors, supporting
     details, contradictions, caveats, and limitations. Produce or reveal it
     on request; store in a structured accompanying file if available.
5. **Coverage audit**: compare L1/L2 against the *full* inventory to check that
   all P0/P1 issues appear, distinctions survive merging, qualifiers remain,
   and all source anchors can be resolved. Do not quietly claim complete
   coverage if the input was truncated or source references are unavailable.
6. **Invite drill-down**: users can ask `expand C03`, `show all P1`, or
   `show source C03`; quote or navigate to the preserved original, not an
   invented reconstruction.

## Default response format (Japanese)

### 一言でいうと
[主旨を1文。書き手の主張と事実を混同しない]

### 私に必要な対応
[対応・判断・確認のみ・対応不要・不明 のいずれか＋1文]

### 重要な論点
- `[C01/P1]` [論点・影響] → [原文参照]
- `[C02/P2]` [論点・影響] → [原文参照]

### 見落とし注意
[重大な例外、矛盾、未確認事項、または追加論点数。なければ省略]

### 参照と詳細
[原文ID、参照可能性、`expand C01` 等の操作方法]

Aim for roughly 200–400 Japanese characters in L1/L2 when appropriate,
**never at the expense of decision-critical information**.

## Non-negotiable rules

- Do not fill gaps with plausible guesses. Label inferred intents as inference.
- Do not treat a source's assertion as established fact.
- Do not discard negative evidence, conditions, exceptions, or minority views.
- Do not assign fake page numbers, line ranges, quotes, or links.
- Source anchors must point to the *original*, not another AI summary.
- When the input is only a pasted message without stable line numbers, assign
  temporary paragraph IDs (`P01`, `P02`, ...) and retain their exact original
  text **if storage is available**. Otherwise label references temporary and
  say that later retrieval is not guaranteed.
- If working with files, preserve originals unchanged; do not silently rewrite
  them. Never upload or save confidential messages to external services without
  permission.
- If an action is high stakes, recommend checking the source passage.
- If coverage verification cannot be completed, explicitly say so.

See `references/compression-rules.md`, `references/output-format.md`, and
`references/traceability.md`. Examples: `examples/`.
