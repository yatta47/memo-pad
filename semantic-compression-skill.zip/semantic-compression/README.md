# semantic-compression

A portable, decision-oriented Agent Skill to reduce the cognitive effort of
reading lengthy messages and AI-produced reviews while retaining source
traceability for on-demand drill-down.

## What it does

- Produces a 1-sentence gist and an explicit **action required / not required**.
- Highlights decision-critical claims before optional context.
- Uses claim IDs (`C01`) linked to original evidence.
- Performs a coverage check to reduce overlooked risks.
- Explains whether reverse navigation is snapshot-backed (R2), reference-backed
  (R1), or unavailable (R0).

> Note: This is not a mathematically lossless compression algorithm. It provides
> reversibility **through retained originals and pointers**, not restoration
> from a short summary.

## Install

This archive contains the **skill directory** `semantic-compression/`.
Place it in a skills directory recognized by your specific agent/version:

- **Claude Code**: typically `.claude/skills/semantic-compression/` (project)
  or `~/.claude/skills/semantic-compression/` (personal).
- **Cursor**: typically `.cursor/skills/semantic-compression/` where Agent Skills
  are supported. Check the version's current Skills settings/documentation.
- **OpenCode**: typically `.opencode/skills/semantic-compression/` (project)
  or `~/.config/opencode/skills/semantic-compression/` (user), where Agent Skills
  are supported. Verify paths with your installed release.

The `SKILL.md` frontmatter is intentionally minimal for portability. No external
network calls, scripts, or special dependencies are required.

## Invoke / try it

Ask your agent:

```text
Use semantic-compression on the following message.
First show only L1 and L2, with evidence anchors and any P0/P1 concerns.
[Paste source text]
```

Then try:

```text
expand C02
show source C02
show all claims
```

Source navigation works only while original content remains available. For
cross-session use, keep the original securely and use durable file/message IDs.

## Files

- `SKILL.md` — main instructions and output contract
- `references/compression-rules.md` — coverage check and priorities
- `references/output-format.md` — optional structured output
- `references/traceability.md` — anchoring and reversibility levels
- `examples/review-example.md` — input/output demonstration

## Privacy

Don't silently forward or upload private incoming messages to an external
service. Follow the organization's data handling rules, especially when
using hosted model providers.
